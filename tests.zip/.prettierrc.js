module.exports = {
    singleQuote: true
};
